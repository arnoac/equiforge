//! EquiForge Pool Miner — Lightweight Mining Client
//!
//! This is a standalone miner that connects to an EquiForge pool server.
//! Users do NOT need a full node, blockchain, or wallet file.
//!
//! Usage:
//!   equiforge-pool-miner --pool 1.2.3.4:9334 --address <your_pubkey_hash> --threads 4
//!
//! To get your address: run `equiforge wallet info` on any machine once,
//! then copy the pubkey_hash and use it everywhere.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Instant;

use serde::{Deserialize, Serialize};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;

use crate::pow;


// ─── Minimal types needed for pool mining ───────────────────────────
// These mirror equiforge::core::types but are duplicated here so this
// binary has zero dependency on the full node crate.
// In a real build, you'd factor these into a shared `equiforge-types` crate.

pub type Hash256 = [u8; 32];

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlockHeader {
    pub version: u32,
    pub prev_hash: Hash256,
    pub merkle_root: Hash256,
    pub timestamp: u64,
    pub difficulty_target: u32,
    pub nonce: u64,
    pub height: u64,
}

/// Count leading zero bits in a hash
pub fn leading_zero_bits(hash: &Hash256) -> u32 {
    let mut count = 0u32;
    for byte in hash {
        if *byte == 0 {
            count += 8;
        } else {
            count += byte.leading_zeros();
            break;
        }
    }
    count
}

// ─── Pool Protocol (must match pool/mod.rs) ─────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PoolMessage {
    Register { worker_name: String, payout_address: String },
    SubmitShare { job_id: u64, nonce: u64 },
    Job { job_id: u64, header: BlockHeader, share_target: u32, network_target: u32 },
    JobCancel,
    ShareAccepted { shares_accepted: u64, hashrate_estimate: f64 },
    ShareRejected { reason: String },
    BlockFound { height: u64, hash: String, finder: String },
    PoolStats { connected_miners: u32, pool_hashrate: f64, blocks_found: u64, current_height: u64 },
}

const MAX_MSG: usize = 1024 * 1024;

async fn read_msg(stream: &mut TcpStream) -> Result<PoolMessage, String> {
    let mut len_buf = [0u8; 4];
    stream.read_exact(&mut len_buf).await.map_err(|e| format!("read: {}", e))?;
    let len = u32::from_le_bytes(len_buf) as usize;
    if len > MAX_MSG { return Err("message too large".into()); }
    let mut buf = vec![0u8; len];
    stream.read_exact(&mut buf).await.map_err(|e| format!("read: {}", e))?;
    bincode::deserialize(&buf).map_err(|e| format!("decode: {}", e))
}

async fn write_msg(stream: &mut TcpStream, msg: &PoolMessage) -> Result<(), String> {
    let data = bincode::serialize(msg).map_err(|e| format!("encode: {}", e))?;
    let len = (data.len() as u32).to_le_bytes();
    stream.write_all(&len).await.map_err(|e| format!("write: {}", e))?;
    stream.write_all(&data).await.map_err(|e| format!("write: {}", e))?;
    stream.flush().await.map_err(|e| format!("flush: {}", e))?;
    Ok(())
}

// ─── PoW Function ───────────────────────────────────────────────────
// Must match equiforge::pow::equihash_x exactly.
// In production, this would be imported from a shared crate.
// For now, the pool miner binary must include pow/mod.rs.

fn hash_header(header: &BlockHeader) -> Hash256 {
    let serialized = bincode::serialize(header).expect("header serialization failed");
    // This must call the same equihash_x function as the full node.
    // The pool miner binary needs to link equiforge::pow::equihash_x.
    pow::equihash_x(&serialized)
}

// ─── Mining Loop ────────────────────────────────────────────────────

struct MiningJob {
    job_id: u64,
    header: BlockHeader,
    share_target: u32,
    network_target: u32,
}

/// Mine a header across multiple threads. Returns (nonce, hash) on success.
fn mine_job(
    job: &MiningJob,
    threads: usize,
    stop: Arc<AtomicBool>,
) -> Option<(u64, Hash256)> {
    let nonce_range = u64::MAX / threads as u64;
    let (tx, rx) = std::sync::mpsc::channel();

    let handles: Vec<_> = (0..threads).map(|i| {
        let mut header = job.header.clone();
        let share_target = job.share_target;
        let stop = stop.clone();
        let tx = tx.clone();
        let start = i as u64 * nonce_range;
        let end = start + nonce_range;

        std::thread::spawn(move || {
            let mut nonce = start;
            while nonce < end {
                if stop.load(Ordering::Relaxed) { return; }

                header.nonce = nonce;
                let serialized = bincode::serialize(&header).expect("serialize");
                let hash = pow::equihash_x(&serialized);

                if leading_zero_bits(&hash) >= share_target {
                    let _ = tx.send((nonce, hash));
                    stop.store(true, Ordering::Relaxed);
                    return;
                }
                nonce += 1;
            }
        })
    }).collect();

    drop(tx);

    let result = rx.recv().ok();

    // Wait for all threads to stop
    stop.store(true, Ordering::Relaxed);
    for h in handles { let _ = h.join(); }

    result
}

// ─── Main Client ────────────────────────────────────────────────────

pub struct PoolMinerConfig {
    pub pool_addr: String,
    pub worker_name: String,
    pub payout_address: String,
    pub threads: usize,
}

pub async fn run_pool_miner(config: PoolMinerConfig) {
    println!("⛏️  EquiForge Pool Miner");
    println!("   Pool:    {}", config.pool_addr);
    println!("   Worker:  {}", config.worker_name);
    println!("   Payout:  {}…", &config.payout_address[..16.min(config.payout_address.len())]);
    println!("   Threads: {}", config.threads);
    println!();

    let mut retry_delay = 1u64;

    loop {
        match connect_and_mine(&config).await {
            Ok(()) => {
                println!("Pool connection closed normally.");
                retry_delay = 1;
            }
            Err(e) => {
                eprintln!("❌ Pool connection error: {}", e);
                eprintln!("   Reconnecting in {}s...", retry_delay);
                tokio::time::sleep(std::time::Duration::from_secs(retry_delay)).await;
                retry_delay = (retry_delay * 2).min(60);
            }
        }
    }
}

async fn connect_and_mine(config: &PoolMinerConfig) -> Result<(), String> {
    let mut stream = TcpStream::connect(&config.pool_addr)
        .await
        .map_err(|e| format!("connect: {}", e))?;
    let _ = stream.set_nodelay(true);
    println!("✅ Connected to pool {}", config.pool_addr);

    // Register
    write_msg(&mut stream, &PoolMessage::Register {
        worker_name: config.worker_name.clone(),
        payout_address: config.payout_address.clone(),
    }).await?;

    let mut current_job: Option<MiningJob> = None;
    let mut total_shares: u64 = 0;
    let mut total_hashes: u64 = 0;
    let session_start = Instant::now();

    loop {
        // Check if we have a job to mine
        if let Some(ref job) = current_job {
            let stop = Arc::new(AtomicBool::new(false));
            let stop2 = stop.clone();
            let job_id = job.job_id;
            let share_target = job.share_target;
            let network_target = job.network_target;
            let height = job.header.height;
            let threads = config.threads;

            // Clone what we need for the mining task
            let header = job.header.clone();
            let mining_job = MiningJob {
                job_id,
                header,
                share_target,
                network_target,
            };

            // Spawn mining in background, watch for pool messages concurrently
            let mine_handle = tokio::task::spawn_blocking(move || {
                mine_job(&mining_job, threads, stop2)
            });

            // While mining, check for pool messages (JobCancel, etc.)
            let cancel_stop = stop.clone();
            let msg_result = tokio::select! {
                // Mining found something
                mine_result = mine_handle => {
                    match mine_result {
                        Ok(Some((nonce, hash))) => {
                            let zeros = leading_zero_bits(&hash);
                            total_shares += 1;

                            if zeros >= network_target {
                                println!("🎉 BLOCK FOUND! height={} hash={} nonce={}", height, hex::encode(hash), nonce);
                            } else {
                                println!("📤 Share #{}: nonce={} zeros={}/{}", total_shares, nonce, zeros, share_target);
                            }

                            // Submit
                            write_msg(&mut stream, &PoolMessage::SubmitShare { job_id, nonce }).await?;

                            // Wait for response
                            match tokio::time::timeout(
                                std::time::Duration::from_secs(10),
                                read_msg(&mut stream),
                            ).await {
                                Ok(Ok(PoolMessage::ShareAccepted { shares_accepted, hashrate_estimate })) => {
                                    let elapsed = session_start.elapsed().as_secs_f64();
                                    println!("✅ Share accepted (total: {}, pool HR est: {:.1} H/s, session: {:.0}s)",
                                        shares_accepted, hashrate_estimate, elapsed);
                                }
                                Ok(Ok(PoolMessage::ShareRejected { reason })) => {
                                    println!("❌ Share rejected: {}", reason);
                                }
                                Ok(Ok(PoolMessage::BlockFound { height, hash, finder })) => {
                                    println!("🎉 Pool block #{} found by {}! hash={}…", height, finder, &hash[..16]);
                                }
                                Ok(Ok(other)) => {
                                    // Could be JobCancel or new Job
                                    handle_control_msg(other, &mut current_job);
                                    continue;
                                }
                                Ok(Err(e)) => return Err(e),
                                Err(_) => println!("⚠️  Share response timeout"),
                            }

                            // Continue mining (will get fresh job or keep same one)
                            continue;
                        }
                        Ok(None) => {
                            // Mining was cancelled (stop flag set by pool message handler below)
                            Ok(())
                        }
                        Err(e) => Err(format!("mining thread panicked: {}", e)),
                    }
                }

                // Pool message while mining
                msg = read_msg(&mut stream) => {
                    cancel_stop.store(true, Ordering::Relaxed);
                    match msg {
                        Ok(msg) => {
                            handle_control_msg(msg, &mut current_job);
                            Ok(())
                        }
                        Err(e) => Err(e),
                    }
                }
            };

            if let Err(e) = msg_result {
                return Err(e);
            }
        } else {
            // No job — wait for one
            match tokio::time::timeout(
                std::time::Duration::from_secs(60),
                read_msg(&mut stream),
            ).await {
                Ok(Ok(msg)) => handle_control_msg(msg, &mut current_job),
                Ok(Err(e)) => return Err(e),
                Err(_) => println!("⏳ Waiting for job from pool..."),
            }
        }
    }
}

fn handle_control_msg(msg: PoolMessage, current_job: &mut Option<MiningJob>) {
    match msg {
        PoolMessage::Job { job_id, header, share_target, network_target } => {
            println!("📋 New job #{}: height={} diff={}/{}", job_id, header.height, share_target, network_target);
            *current_job = Some(MiningJob { job_id, header, share_target, network_target });
        }
        PoolMessage::JobCancel => {
            println!("🔄 Job cancelled (new block arrived)");
            *current_job = None;
        }
        PoolMessage::BlockFound { height, hash, finder } => {
            println!("🎉 Pool found block #{} by {} ({}…)", height, finder, &hash[..16.min(hash.len())]);
        }
        PoolMessage::PoolStats { connected_miners, pool_hashrate, blocks_found, current_height } => {
            println!("📊 Pool: {} miners, {:.1} H/s, {} blocks, height {}",
                connected_miners, pool_hashrate, blocks_found, current_height);
        }
        PoolMessage::ShareAccepted { .. } | PoolMessage::ShareRejected { .. } => {
            // Handled inline after submission
        }
        _ => {}
    }
}